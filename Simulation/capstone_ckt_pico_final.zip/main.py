from machine import Pin, ADC, I2C
import time
from i2c_lcd import I2cLcd
from keypad import Keypad

# Initialize I2C for the LCD
i2c = I2C(0, scl=Pin(1), sda=Pin(0), freq=400000)
I2C_ADDR = 0x27  # Typical I2C address for LCD
lcd = I2cLcd(i2c, I2C_ADDR, 2, 16)  # 2 lines, 16 characters per line

# Define the pin connections
ldr = ADC(26)  # Analog pin for LDR (ADC0 is GPIO 26 on Raspberry Pi Pico)
buzzer = Pin(16, Pin.OUT)  # GPIO pin for Buzzer
button = Pin(15, Pin.IN, Pin.PULL_DOWN)  # GPIO pin for Button

# Keypad setup
KEYPAD_ROWS = [6, 7, 8, 9]  # Change according to your setup
KEYPAD_COLS = [10, 11, 12, 13]  # Change according to your setup
keypad = Keypad(KEYPAD_ROWS, KEYPAD_COLS)

# Mock function for uploading data
def upload_data(glucose_level):
    print(f"Uploading glucose level: {glucose_level}")
    # Here you would add code to upload the glucose level to your website

from machine import Pin, ADC, I2C
import time
from i2c_lcd import I2cLcd
from keypad import Keypad

# Initialize I2C for the LCD
i2c = I2C(0, scl=Pin(1), sda=Pin(0), freq=400000)
I2C_ADDR = 0x27  # Typical I2C address for LCD
lcd = I2cLcd(i2c, I2C_ADDR, 2, 16)  # 2 lines, 16 characters per line

# Define the pin connections
ldr = ADC(26)  # Analog pin for LDR (ADC0 is GPIO 26 on Raspberry Pi Pico)
buzzer = Pin(16, Pin.OUT)  # GPIO pin for Buzzer
button = Pin(15, Pin.IN, Pin.PULL_DOWN)  # GPIO pin for Button

# Keypad setup
KEYPAD_ROWS = [6, 7, 8, 9]  # Change according to your setup
KEYPAD_COLS = [10, 11, 12, 13]  # Change according to your setup
keypad = Keypad(KEYPAD_ROWS, KEYPAD_COLS)

# Mock function for uploading data
def upload_data(glucose_level):
    print(f"Uploading glucose level: {glucose_level}")
    # Here you would add code to upload the glucose level to your website


def get_keypad_input():
    print("Enter BMI (end with #): ")
    bmi = keypad.get_input()  # Placeholder function to get input from keypad
    print(f"BMI: {bmi}")
    print("Enter Age (end with #): ")
    age = keypad.get_input()  # Placeholder function to get input from keypad
    print(f"Age: {age}")
    return float(bmi), int(age)


while True:
    ldr_value = ldr.read_u16()  # Read the LDR value
    print("LDR Value:", ldr_value)
    
    # Get BMI and Age from keypad input
    bmi, age = get_keypad_input()
    
    # Calculate the glucose level using the regression formula
    glucose_level = ((0.000009) * (ldr_value) * (ldr_value)) + (0.1788 * (ldr_value)) + 49.454 
    #glucose_level = (0.36327 * (ldr_value)) - 44.6135 + ((bmi)*(0.148)) + ((age)*(0.0257))

    # Display the glucose level in the Serial Monitor
    print("Glucose Level:", glucose_level)
    
    # Display the glucose level on the LCD
    lcd.clear()
    lcd.write_string(f"Glucose: {glucose_level:.2f}")
    
    # Use the glucose level to control the Buzzer
    if glucose_level > 150:  # Example threshold value for high glucose level
        buzzer.value(1)  # Turn on Buzzer
    else:
        buzzer.value(0)  # Turn off Buzzer
    
    # Check if the button is pressed to upload data
    if button.value() == 1:
        upload_data(glucose_level)
    
    time.sleep(0.1)


