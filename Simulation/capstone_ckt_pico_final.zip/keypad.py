from machine import Pin

class Keypad:
    def __init__(self, row_pins, col_pins):
        self.row_pins = [Pin(pin, Pin.OUT) for pin in row_pins]
        self.col_pins = [Pin(pin, Pin.IN, Pin.PULL_DOWN) for pin in col_pins]
        self.keys = [
            ['1', '2', '3', 'A'],
            ['4', '5', '6', 'B'],
            ['7', '8', '9', 'C'],
            ['*', '0', '#', 'D']
        ]
    
    def get_input(self):
        input_val = ""
        while True:
            for row_num, row_pin in enumerate(self.row_pins):
                row_pin.value(1)
                for col_num, col_pin in enumerate(self.col_pins):
                    if col_pin.value() == 1:
                        input_val += self.keys[row_num][col_num]
                        print(self.keys[row_num][col_num])
                        while col_pin.value() == 1:
                            pass  # Wait for key release
                row_pin.value(0)
            if len(input_val) > 0:
                break
        return input_val
