class LcdApi:
    """ Base class for LCD display using I2C. """

    def __init__(self, num_lines, num_columns):
        self.num_lines = num_lines
        self.num_columns = num_columns
        self.cursor_x = 0
        self.cursor_y = 0
        self.backlight = True

    def clear(self):
        self.write_command(0x01)
        self.cursor_x = 0
        self.cursor_y = 0

    def home(self):
        self.write_command(0x02)
        self.cursor_x = 0
        self.cursor_y = 0

    def write_string(self, string):
        for char in string:
            self.write_data(ord(char))

    def move_to(self, cursor_x, cursor_y):
        self.cursor_x = cursor_x
        self.cursor_y = cursor_y
        addr = cursor_x & 0x7F
        if cursor_y == 1:
            addr += 0x40
        self.write_command(0x80 | addr)

    def hide_cursor(self):
        self.write_command(0x0C)

    def show_cursor(self):
        self.write_command(0x0E)

    def blink_cursor_on(self):
        self.write_command(0x0F)

    def blink_cursor_off(self):
        self.write_command(0x0E)

    def backlight_on(self):
        self.backlight = True
        self.backlight_changed()

    def backlight_off(self):
        self.backlight = False
        self.backlight_changed()

    def backlight_changed(self):
        pass

    def write_command(self, cmd):
        raise NotImplementedError

    def write_data(self, data):
        raise NotImplementedError
