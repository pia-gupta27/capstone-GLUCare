from machine import I2C
import time
from lcd_api import LcdApi

class I2cLcd(LcdApi):
    """ Implements the LCD API for an I2C LCD display. """

    def __init__(self, i2c, i2c_addr, num_lines, num_columns):
        self.i2c = i2c
        self.i2c_addr = i2c_addr
        self.num_lines = num_lines
        self.num_columns = num_columns
        self.backlight = True

        self.init_display()

    def init_display(self):
        time.sleep(0.02)    # Wait 20ms for the LCD to power up.
        self.write_init_nibble(0x03)
        time.sleep(0.005)   # Wait 5ms
        self.write_init_nibble(0x03)
        time.sleep(0.001)
        self.write_init_nibble(0x03)
        time.sleep(0.001)
        self.write_init_nibble(0x02)  # Enter 4-bit mode

        self.write_command(0x28)  # Function set: 4-bit mode, 2 lines, 5x8 dots
        self.write_command(0x08)  # Display off
        self.write_command(0x01)  # Clear display
        time.sleep(0.002)
        self.write_command(0x06)  # Entry mode set: Increment automatically, no display shift
        self.write_command(0x0C)  # Display on, no cursor, no blink

    def write_init_nibble(self, nibble):
        self.i2c.writeto(self.i2c_addr, bytearray([0x30 | (nibble << 4)]))
        self.i2c.writeto(self.i2c_addr, bytearray([0x20 | (nibble << 4)]))

    def write_command(self, cmd):
        self.write_byte(cmd, 0)

    def write_data(self, data):
        self.write_byte(data, 1)

    def write_byte(self, byte, mode):
        byte = byte & 0xF0 | mode << 6 | (self.backlight << 3)
        self.i2c.writeto(self.i2c_addr, bytearray([byte | 0x04]))
        self.i2c.writeto(self.i2c_addr, bytearray([byte]))

        byte = (byte << 4) & 0xF0 | mode << 6 | (self.backlight << 3)
        self.i2c.writeto(self.i2c_addr, bytearray([byte | 0x04]))
        self.i2c.writeto(self.i2c_addr, bytearray([byte]))

    def backlight_changed(self):
        self.i2c.writeto(self.i2c_addr, bytearray([0x08 | self.backlight << 3]))
