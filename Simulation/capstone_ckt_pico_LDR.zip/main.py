from machine import Pin, ADC
import time

# Define the pin connections
ldr = ADC(26)  # Analog pin for LDR (ADC0 is GPIO 26 on Raspberry Pi Pico)
led = Pin(16, Pin.OUT)  # GPIO pin for LED

while True:
    ldr_value = ldr.read_u16()  # Read the LDR value
    print("LDR Value:", ldr_value)
    
    # Calculate the glucose level using the regression formula
    #glucose_level = ((0.000009) * (ldr_value) * (ldr_value)) + (0.1788 * (ldr_value)) + 49.454
    
    glucose_level = ((-0.00005) * (ldr_value) * (ldr_value)) + (0.4176 * (ldr_value)) - 54.132
    # Display the glucose level in the Serial Monitor
    print("Glucose Level:", glucose_level)
    
    # Use the glucose level to control the LED
    if glucose_level > 150:  # Example threshold value for high glucose level
        led.value(1)  # Turn on LED
    else:
        led.value(0)  # Turn off LED
    
    time.sleep(0.1)
